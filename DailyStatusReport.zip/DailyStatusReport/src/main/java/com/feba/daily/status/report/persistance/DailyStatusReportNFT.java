package com.feba.daily.status.report.persistance;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="DAILY_STATUS_REPORT_NFT", uniqueConstraints = { @UniqueConstraint( columnNames = { "REPORT_DATE", "SDP_ID" } ), @UniqueConstraint( columnNames = { "REPORT_DATE", "LOBS" } ) })
//, uniqueConstraints = { @UniqueConstraint( columnNames = { "INSERTED_DATE", "SDP_ID" } ) }
public class DailyStatusReportNFT 
{
	@Id
	@GeneratedValue
	@Column(name = "DAILY_STS_RPT_ID")
	private long id;
	
	@Column(name = "PLANING_PHASE_START")
	@Temporal(TemporalType.DATE)
	private Date planingPhaseStart;
	
	@Column(name = "PLANING_PHASE_END")
	@Temporal(TemporalType.DATE)
	private Date planingPhaseEnd;
	
	@Column(name = "TEST_DESIGN_PHASE_START")
	@Temporal(TemporalType.DATE)
	private Date testDesignPhaseStart;
	
	@Column(name = "TEST_DESIGN_PHASE_END")
	@Temporal(TemporalType.DATE)
	private Date testDesignPhaseEnd;
	
	@Column(name = "EXECUTION_PHASE_START")
	@Temporal(TemporalType.DATE)
	private Date executionPhaseStart;
	
	@Column(name = "EXECUTION_PHASE_END")
	@Temporal(TemporalType.DATE)
	private Date executionPhaseEnd;
	
	@Column(name = "SIGN_OFF_AND_CLOSURE_PHASE_START")
	@Temporal(TemporalType.DATE)
	private Date signOffAndClosurePhaseStart;
	
	@Column(name = "SIGN_OFF_AND_CLOSURE_PHASE_END")
	@Temporal(TemporalType.DATE)
	private Date signOffAndClosurePhaseEnd;
	
	@Column(name = "PROJECT_RELEASE")
	private String projectRelease;
	
	@Column(name = "LOBS")
	private String loB;
	
	@Column(name = "APP_NAME")
	private String appName;
	
	@Column(name = "PLANING_PHASE_PERCENTAGE")
	private String planingPhasePercentage;
	
	@Column(name = "TEST_DESIGN_PHASE_PERCENTAGE")
	private String testDesignPhasePercentage;
	
	@Column(name = "EXECUTION_PHASE_PERCENTAGE")
	private String executionPhasePercentage;
	
	@Column(name = "SIGN_OFF_AND_CLOSURE_PHASE_PERCENTAGE")
	private String signOffAndClosurePhasePercentage;
	
	@Column(name = "OVER_ALL_PT_COMPLETION_STATUS_PERCENTAGE")
	private String overAllPtCompletionStatusPercentage;
	
	@Column(name = "RELEASE_DATE")
	@Temporal(TemporalType.DATE)
	private Date releaseDate;
	
	@Column(name = "REPORT_DATE", updatable=false)
	@Temporal(TemporalType.DATE)
	private Date reportDate;
	
	@Column(name = "SDP_ID", updatable=false)
	private String sdpId;
	
	@Column(name = "CODE_BUILD_VERSION_TEST_ENV")
	private String codeBuildVersionTestEnv;
	
	@Column(name = "INSERTED_DATE", updatable=false)
	@Temporal(TemporalType.DATE)
	private Date insertedDate;
	
	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.DATE)
	private Date modifiedDate;
	
	@Column(name = "IS_ENABLED")
	private boolean isEnabled;
	
	@Column(name = "IS_DELTED")
	private boolean isDeleted;
	
	@Column(name = "HIGH_LEVEL_STATUS_OR_ACCOMPLISHMENTS")
	private String highLevelStatusOrAccomplishments;
	
	@Column(name = "KEY_REASON_FOR_NON_GREEN")
	private String keyReasonsForNonGreen;
	
	@Column(name = "BACK_TO_GREEN_PLAN")
	private String backToGreenPlan;
	
	@Column(name = "OWNER")
	private String owner;	
	
	@Column(name = "OVER_ALL_PT_COMPLETION_STATUS")
	private String overAllPtCompletionStatus;
	
	@Column(name = "TRACK_STATUS")
	private String trackStatus;
	
	@Column(name = "CITY_CONNECT")
	private String cityConnect;
	
	@Column(name = "CD")
	private String cd;
	
	@Column(name = "STATE_STREET")
	private String stateStreet;
	
	@Column(name = "SHARED_SERVICES")
	private String sharedServices;
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="FK_DAILY_STS_RPT_ID")
	private Set<RaidLog> raidLogs;
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_TEST_DGN_SMRY_ID")
	private Set<TestDesignSummary> testDesignSummaries;
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_TEST_EXEC_SMRY_ID")
	private Set<TestExecutionSummary> testExecutionSummaries;
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_TEST_DEFECT_SMRY_ID")
	private Set<TestDefectSummary> testDefectSummaries;
	
	
	//GIW enhancement
	
	@Column(name = "GO_LIVE_DATE_1")
	@Temporal(TemporalType.DATE)
	private Date goLiveDate1;
	
	@Column(name = "GO_LIVE_DATE_2")
	@Temporal(TemporalType.DATE)
	private Date goLiveDate2;
	
	@Column(name = "GO_LIVE_DATE_3")
	@Temporal(TemporalType.DATE)
	private Date goLiveDate3;
	
	@Column(name = "GO_LIVE_DATE_4")
	@Temporal(TemporalType.DATE)
	private Date goLiveDate4;
		 
	@Column(name = "EXECUTION_COMPLETION_1")
	private double executionCompletion1;
	
	@Column(name = "EXECUTION_COMPLETION_2")
	private double executionCompletion2;
	
	@Column(name = "EXECUTION_COMPLETION_3")
	private double executionCompletion3;
	
	@Column(name = "EXECUTION_COMPLETION_4")
	private double executionCompletion4;
	
	@Column(name = "GIW_RAG_1")
	private String giwRag1;
	
	@Column(name = "GIW_RAG_2")
	private String giwRag2;
	
	@Column(name = "GIW_RAG_3")
	private String giwRag3;
	
	@Column(name = "GIW_RAG_4")
	private String giwRag4;
	
	@Column(name = "GIW_OVR_ALL_PT_COMLTION_STS1")
	private String giwOverAllPtCompletionStatus1;
	
	@Column(name = "GIW_OVR_ALL_PT_COMLTION_STS2")
	private String giwOverAllPtCompletionStatus2;
	
	@Column(name = "GIW_OVR_ALL_PT_COMLTION_STS3")
	private String giwOverAllPtCompletionStatus3;
	
	@Column(name = "GIW_OVR_ALL_PT_COMLTION_STS4")
	private String giwOverAllPtCompletionStatus4;
	
	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="FK_GIW_DAILY_STS_RPT_ID")
	private Set<GIWExecutionSummary> giwExecutionSummaries;
	

	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	public Date getPlaningPhaseStart()
	{
		return planingPhaseStart;
	}

	public void setPlaningPhaseStart(Date planingPhaseStart)
	{
		this.planingPhaseStart = planingPhaseStart;
	}

	public Date getPlaningPhaseEnd()
	{
		return planingPhaseEnd;
	}

	public void setPlaningPhaseEnd(Date planingPhaseEnd)
	{
		this.planingPhaseEnd = planingPhaseEnd;
	}

	public Date getTestDesignPhaseStart()
	{
		return testDesignPhaseStart;
	}

	public void setTestDesignPhaseStart(Date testDesignPhaseStart)
	{
		this.testDesignPhaseStart = testDesignPhaseStart;
	}

	public Date getTestDesignPhaseEnd()
	{
		return testDesignPhaseEnd;
	}

	public void setTestDesignPhaseEnd(Date testDesignPhaseEnd)
	{
		this.testDesignPhaseEnd = testDesignPhaseEnd;
	}

	public Date getExecutionPhaseStart()
	{
		return executionPhaseStart;
	}

	public void setExecutionPhaseStart(Date executionPhaseStart)
	{
		this.executionPhaseStart = executionPhaseStart;
	}

	public Date getExecutionPhaseEnd()
	{
		return executionPhaseEnd;
	}

	public void setExecutionPhaseEnd(Date executionPhaseEnd)
	{
		this.executionPhaseEnd = executionPhaseEnd;
	}

	public Date getSignOffAndClosurePhaseStart()
	{
		return signOffAndClosurePhaseStart;
	}

	public void setSignOffAndClosurePhaseStart(Date signOffAndClosurePhaseStart)
	{
		this.signOffAndClosurePhaseStart = signOffAndClosurePhaseStart;
	}

	public Date getSignOffAndClosurePhaseEnd()
	{
		return signOffAndClosurePhaseEnd;
	}

	public void setSignOffAndClosurePhaseEnd(Date signOffAndClosurePhaseEnd)
	{
		this.signOffAndClosurePhaseEnd = signOffAndClosurePhaseEnd;
	}

	public String getProjectRelease()
	{
		return projectRelease;
	}

	public void setProjectRelease(String projectRelease)
	{
		this.projectRelease = projectRelease;
	}

	public String getLoB()
	{
		return loB;
	}

	public void setLoB(String loB)
	{
		this.loB = loB;
	}

	public String getAppName()
	{
		return appName;
	}

	public void setAppName(String appName)
	{
		this.appName = appName;
	}

	public String getPlaningPhasePercentage()
	{
		return planingPhasePercentage;
	}

	public void setPlaningPhasePercentage(String planingPhasePercentage)
	{
		this.planingPhasePercentage = planingPhasePercentage;
	}

	public String getTestDesignPhasePercentage()
	{
		return testDesignPhasePercentage;
	}

	public void setTestDesignPhasePercentage(String testDesignPhasePercentage)
	{
		this.testDesignPhasePercentage = testDesignPhasePercentage;
	}

	public String getExecutionPhasePercentage()
	{
		return executionPhasePercentage;
	}

	public void setExecutionPhasePercentage(String executionPhasePercentage)
	{
		this.executionPhasePercentage = executionPhasePercentage;
	}

	public String getSignOffAndClosurePhasePercentage()
	{
		return signOffAndClosurePhasePercentage;
	}

	public String getOverAllPtCompletionStatusPercentage()
	{
		return overAllPtCompletionStatusPercentage;
	}

	public void setOverAllPtCompletionStatusPercentage(String overAllPtCompletionStatusPercentage)
	{
		this.overAllPtCompletionStatusPercentage = overAllPtCompletionStatusPercentage;
	}

	public void setSignOffAndClosurePhasePercentage(String signOffAndClosurePhasePercentage)
	{
		this.signOffAndClosurePhasePercentage = signOffAndClosurePhasePercentage;
	}

	public Date getReleaseDate()
	{
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate)
	{
		this.releaseDate = releaseDate;
	}

	public Date getReportDate()
	{
		return reportDate;
	}

	public void setReportDate(Date reportDate)
	{
		this.reportDate = reportDate;
	}

	public String getSdpId()
	{
		return sdpId;
	}

	public void setSdpId(String sdpId)
	{
		this.sdpId = sdpId;
	}

	public String getCodeBuildVersionTestEnv()
	{
		return codeBuildVersionTestEnv;
	}

	public void setCodeBuildVersionTestEnv(String codeBuildVersionTestEnv)
	{
		this.codeBuildVersionTestEnv = codeBuildVersionTestEnv;
	}

	public Date getInsertedDate()
	{
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate)
	{
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate()
	{
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate)
	{
		this.modifiedDate = modifiedDate;
	}

	public boolean isEnabled()
	{
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled)
	{
		this.isEnabled = isEnabled;
	}

	public boolean isDeleted()
	{
		return isDeleted;
	}

	public String getOverAllPtCompletionStatus()
	{
		return overAllPtCompletionStatus;
	}

	public void setOverAllPtCompletionStatus(String overAllPtCompletionStatus)
	{
		this.overAllPtCompletionStatus = overAllPtCompletionStatus;
	}

	public String getTrackStatus()
	{
		return trackStatus;
	}

	public void setTrackStatus(String trackStatus)
	{
		this.trackStatus = trackStatus;
	}

	public String getCityConnect()
	{
		return cityConnect;
	}

	public void setCityConnect(String cityConnect)
	{
		this.cityConnect = cityConnect;
	}

	public String getCd()
	{
		return cd;
	}

	public void setCd(String cd)
	{
		this.cd = cd;
	}

	public String getStateStreet()
	{
		return stateStreet;
	}

	public void setStateStreet(String stateStreet)
	{
		this.stateStreet = stateStreet;
	}

	public String getSharedServices()
	{
		return sharedServices;
	}

	public void setSharedServices(String sharedServices)
	{
		this.sharedServices = sharedServices;
	}

	public Set<RaidLog> getRaidLogs()
	{
		return raidLogs;
	}

	public void setRaidLogs(Set<RaidLog> raidLogs)
	{
		this.raidLogs = raidLogs;
	}

	public void setDeleted(boolean isDeleted)
	{
		this.isDeleted = isDeleted;
	}

	public String getHighLevelStatusOrAccomplishments()
	{
		return highLevelStatusOrAccomplishments;
	}

	public void setHighLevelStatusOrAccomplishments(String highLevelStatusOrAccomplishments)
	{
		this.highLevelStatusOrAccomplishments = highLevelStatusOrAccomplishments;
	}

	public String getKeyReasonsForNonGreen()
	{
		return keyReasonsForNonGreen;
	}

	public void setKeyReasonsForNonGreen(String keyReasonsForNonGreen)
	{
		this.keyReasonsForNonGreen = keyReasonsForNonGreen;
	}

	public String getBackToGreenPlan()
	{
		return backToGreenPlan;
	}

	public void setBackToGreenPlan(String backToGreenPlan)
	{
		this.backToGreenPlan = backToGreenPlan;
	}

	public String getOwner()
	{
		return owner;
	}

	public void setOwner(String owner)
	{
		this.owner = owner;
	}

	public Set<TestDesignSummary> getTestDesignSummaries()
	{
		return testDesignSummaries;
	}

	public void setTestDesignSummaries(Set<TestDesignSummary> testDesignSummaries)
	{
		this.testDesignSummaries = testDesignSummaries;
	}

	public Set<TestExecutionSummary> getTestExecutionSummaries()
	{
		return testExecutionSummaries;
	}

	public void setTestExecutionSummaries(Set<TestExecutionSummary> testExecutionSummaries)
	{
		this.testExecutionSummaries = testExecutionSummaries;
	}

	public Set<TestDefectSummary> getTestDefectSummaries()
	{
		return testDefectSummaries;
	}

	public void setTestDefectSummaries(Set<TestDefectSummary> testDefectSummaries)
	{
		this.testDefectSummaries = testDefectSummaries;
	}

	public Date getGoLiveDate1()
	{
		return goLiveDate1;
	}

	public void setGoLiveDate1(Date goLiveDate1)
	{
		this.goLiveDate1 = goLiveDate1;
	}

	public Date getGoLiveDate2()
	{
		return goLiveDate2;
	}

	public void setGoLiveDate2(Date goLiveDate2)
	{
		this.goLiveDate2 = goLiveDate2;
	}

	public Date getGoLiveDate3()
	{
		return goLiveDate3;
	}

	public void setGoLiveDate3(Date goLiveDate3)
	{
		this.goLiveDate3 = goLiveDate3;
	}

	public Date getGoLiveDate4()
	{
		return goLiveDate4;
	}

	public void setGoLiveDate4(Date goLiveDate4)
	{
		this.goLiveDate4 = goLiveDate4;
	}

	public double getExecutionCompletion1()
	{
		return executionCompletion1;
	}

	public void setExecutionCompletion1(double executionCompletion1)
	{
		this.executionCompletion1 = executionCompletion1;
	}

	public double getExecutionCompletion2()
	{
		return executionCompletion2;
	}

	public void setExecutionCompletion2(double executionCompletion2)
	{
		this.executionCompletion2 = executionCompletion2;
	}

	public double getExecutionCompletion3()
	{
		return executionCompletion3;
	}

	public void setExecutionCompletion3(double executionCompletion3)
	{
		this.executionCompletion3 = executionCompletion3;
	}

	public double getExecutionCompletion4()
	{
		return executionCompletion4;
	}

	public void setExecutionCompletion4(double executionCompletion4)
	{
		this.executionCompletion4 = executionCompletion4;
	}

	public String getGiwRag1()
	{
		return giwRag1;
	}

	public void setGiwRag1(String giwRag1)
	{
		this.giwRag1 = giwRag1;
	}

	public String getGiwRag2()
	{
		return giwRag2;
	}

	public void setGiwRag2(String giwRag2)
	{
		this.giwRag2 = giwRag2;
	}

	public String getGiwRag3()
	{
		return giwRag3;
	}

	public void setGiwRag3(String giwRag3)
	{
		this.giwRag3 = giwRag3;
	}

	public String getGiwRag4()
	{
		return giwRag4;
	}

	public void setGiwRag4(String giwRag4)
	{
		this.giwRag4 = giwRag4;
	}

	public String getGiwOverAllPtCompletionStatus1()
	{
		return giwOverAllPtCompletionStatus1;
	}

	public void setGiwOverAllPtCompletionStatus1(String giwOverAllPtCompletionStatus1)
	{
		this.giwOverAllPtCompletionStatus1 = giwOverAllPtCompletionStatus1;
	}

	public String getGiwOverAllPtCompletionStatus2()
	{
		return giwOverAllPtCompletionStatus2;
	}

	public void setGiwOverAllPtCompletionStatus2(String giwOverAllPtCompletionStatus2)
	{
		this.giwOverAllPtCompletionStatus2 = giwOverAllPtCompletionStatus2;
	}

	public String getGiwOverAllPtCompletionStatus3()
	{
		return giwOverAllPtCompletionStatus3;
	}

	public void setGiwOverAllPtCompletionStatus3(String giwOverAllPtCompletionStatus3)
	{
		this.giwOverAllPtCompletionStatus3 = giwOverAllPtCompletionStatus3;
	}

	public String getGiwOverAllPtCompletionStatus4()
	{
		return giwOverAllPtCompletionStatus4;
	}

	public void setGiwOverAllPtCompletionStatus4(String giwOverAllPtCompletionStatus4)
	{
		this.giwOverAllPtCompletionStatus4 = giwOverAllPtCompletionStatus4;
	}

	public Set<GIWExecutionSummary> getGiwExecutionSummaries()
	{
		return giwExecutionSummaries;
	}

	public void setGiwExecutionSummaries(Set<GIWExecutionSummary> giwExecutionSummaries)
	{
		this.giwExecutionSummaries = giwExecutionSummaries;
	}
	
}
