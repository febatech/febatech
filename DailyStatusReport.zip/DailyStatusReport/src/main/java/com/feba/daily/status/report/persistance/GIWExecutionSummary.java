package com.feba.daily.status.report.persistance;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "GIW_EXECUTION_SUMMARY")
public class GIWExecutionSummary
{
	
	@Id
	@GeneratedValue
	@Column(name = "ID")
	private long id;
	
	@Column(name = "TRACK")
	private String track;
	
	@Column(name = "PROJECT_ID")
	private String projectId;
	
	@Column(name = "SN_TICKET")
	private String snTicket;
	
	@Column(name = "SDP_REQ")
	private String sdpReq;
	
	@Column(name = "DESCRIPTION")
	private String description;
	
	@Column(name = "GO_LIVE_DATE")
	@Temporal(TemporalType.DATE)
	private Date goLiveDate;
	
	@Column(name = "REQ_RECEIVE_ON")
	@Temporal(TemporalType.DATE)
	private Date reqReceiveOn;
	
	@Column(name = "TENTATIVE_START_DATE")
	@Temporal(TemporalType.DATE)
	private Date tentativeStartDate;
	
	@Column(name = "TENTATIVE_END_DATE")
	@Temporal(TemporalType.DATE)
	private Date tentativeEndDate;
	
	@Column(name = "RAG_STATUS")
	private String ragStatus;
	
	@Column(name = "STATUS")
	private String status;
	
	@Column(name = "COMPLETION")
	private String completion;
	
	@Column(name = "COMMENTS")
	private String comments;
	
	@Column(name = "BACK_TO_GREEN_PLAN")
	private String backToGreenPlan;
	
	@Column(name = "OWNER")
	private String owner;
	
	@Column(name = "INSERTED_DATE", updatable=false)
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date insertedDate;
	
	@Column(name = "MODIFIED_DATE")
	@Temporal(TemporalType.DATE)
	private Date modifiedDate;
	
	@Column(name = "IS_ENABLED")
	private boolean isEnabled;
	
	@Column(name = "IS_DELTED")
	private boolean isDeleted;

	@ManyToOne(cascade = CascadeType.ALL,  fetch = FetchType.EAGER)
	@JoinColumn(name = "FK_GIW_DAILY_STS_RPT_ID")
	private DailyStatusReportNFT dailyStatusReportNFT;

	public long getId()
	{
		return id;
	}

	public void setId(long id)
	{
		this.id = id;
	}

	public String getTrack()
	{
		return track;
	}

	public void setTrack(String track)
	{
		this.track = track;
	}

	public String getProjectId()
	{
		return projectId;
	}

	public void setProjectId(String projectId)
	{
		this.projectId = projectId;
	}

	public String getSnTicket()
	{
		return snTicket;
	}

	public void setSnTicket(String snTicket)
	{
		this.snTicket = snTicket;
	}

	public String getSdpReq()
	{
		return sdpReq;
	}

	public void setSdpReq(String sdpReq)
	{
		this.sdpReq = sdpReq;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description)
	{
		this.description = description;
	}

	public Date getGoLiveDate()
	{
		return goLiveDate;
	}

	public void setGoLiveDate(Date goLiveDate)
	{
		this.goLiveDate = goLiveDate;
	}

	public Date getReqReceiveOn()
	{
		return reqReceiveOn;
	}

	public void setReqReceiveOn(Date reqReceiveOn)
	{
		this.reqReceiveOn = reqReceiveOn;
	}

	public Date getTentativeStartDate()
	{
		return tentativeStartDate;
	}

	public void setTentativeStartDate(Date tentativeStartDate)
	{
		this.tentativeStartDate = tentativeStartDate;
	}

	public Date getTentativeEndDate()
	{
		return tentativeEndDate;
	}

	public void setTentativeEndDate(Date tentativeEndDate)
	{
		this.tentativeEndDate = tentativeEndDate;
	}

	public String getRagStatus()
	{
		return ragStatus;
	}

	public void setRagStatus(String ragStatus)
	{
		this.ragStatus = ragStatus;
	}

	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	public String getCompletion()
	{
		return completion;
	}

	public void setCompletion(String completion)
	{
		this.completion = completion;
	}

	public String getComments()
	{
		return comments;
	}

	public void setComments(String comments)
	{
		this.comments = comments;
	}

	public String getBackToGreenPlan()
	{
		return backToGreenPlan;
	}

	public void setBackToGreenPlan(String backToGreenPlan)
	{
		this.backToGreenPlan = backToGreenPlan;
	}

	public String getOwner()
	{
		return owner;
	}

	public void setOwner(String owner)
	{
		this.owner = owner;
	}

	public Date getInsertedDate()
	{
		return insertedDate;
	}

	public void setInsertedDate(Date insertedDate)
	{
		this.insertedDate = insertedDate;
	}

	public Date getModifiedDate()
	{
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate)
	{
		this.modifiedDate = modifiedDate;
	}

	public boolean isEnabled()
	{
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled)
	{
		this.isEnabled = isEnabled;
	}

	public boolean isDeleted()
	{
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted)
	{
		this.isDeleted = isDeleted;
	}

	public DailyStatusReportNFT getDailyStatusReportNFT()
	{
		return dailyStatusReportNFT;
	}

	public void setDailyStatusReportNFT(DailyStatusReportNFT dailyStatusReportNFT)
	{
		this.dailyStatusReportNFT = dailyStatusReportNFT;
	}

	
	
}
